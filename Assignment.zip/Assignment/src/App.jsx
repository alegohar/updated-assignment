import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
function App() {
  
  return (
    <>
    <div className="text-slate-500 bg-black">asdas</div>
    <div>asdas</div>
    </>
  )
}

export default App
