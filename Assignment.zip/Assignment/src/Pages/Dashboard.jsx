import React from "react";

const Dashboard = ()=>
{   return (<div>Teacher's dashboasdasdard</div>);
}

export default Dashboard;